import pandas as pd
import re
from pathlib import Path
from math import ceil


def extract_jlpt_level(tags):
    """Extract JLPT level from tags column."""
    if pd.isna(tags) or not isinstance(tags, str):
        return None
    match = re.search(r'JLPT_([Nn][1-5])', tags)
    if match:
        return match.group(1).upper()
    return None


def load_kanji_meanings(joyo_file='joyo.csv'):
    """Load kanji meanings from joyo.csv into a dict."""
    if not Path(joyo_file).exists():
        return {}
    df = pd.read_csv(joyo_file)
    meanings = {}
    for _, row in df.iterrows():
        kanji = row['kanji']
        meaning = row.get('meanings', '')
        if pd.notna(meaning):
            meanings[kanji] = str(meaning).split('|')[0]
        else:
            meanings[kanji] = ''
    return meanings


def build_kanji_fragment(kanji_rows, kanji_to_vocab, kanji_meanings, running_index_start, group_size=30):
    """Build an HTML fragment for a list of kanji, grouped into batches of group_size."""
    total = len(kanji_rows)
    num_groups = ceil(total / group_size)
    idx = running_index_start
    html = f'<div class="stats">📖 {total} kanji (groups of {group_size})</div>\n'

    for g in range(num_groups):
        lo = g * group_size
        hi = min(lo + group_size, total)
        group = kanji_rows[lo:hi]

        html += (
            f'<div class="kanji-group-section collapsed">\n'
            f'  <div class="kanji-group-header" onclick="toggleKanjiGroup(this.parentElement)">\n'
            f'    <span>📚 Kanji {lo+1}–{hi} ({len(group)} characters)</span>\n'
            f'    <span class="kanji-group-toggle">▼</span>\n'
            f'  </div>\n'
            f'  <div class="kanji-group-content">\n'
        )

        for _, row in group:
            kanji = row['kanji']
            meanings = str(row['meanings'])[:80] if pd.notna(row['meanings']) else ''
            strokes = row['strokes'] if pd.notna(row['strokes']) else '?'
            on_r = str(row['on']).replace('|', ' · ') if pd.notna(row['on']) else '—'
            kun_r = str(row['kun']).replace('|', ' · ') if pd.notna(row['kun']) else '—'
            vocab_by_level = kanji_to_vocab.get(kanji, {})

            html += (
                f'<div class="kanji-card collapsed" data-kanji="{kanji}" '
                f'data-meanings="{meanings.lower()}" data-readings="{on_r} {kun_r}">\n'
                f'  <div class="kanji-header" onclick="toggleKanji(this.parentElement)">\n'
                f'    <div class="kanji-header-left">\n'
                f'      <div class="kanji-char">{kanji}</div>\n'
                f'      <div class="kanji-summary">\n'
                f'        <div class="kanji-meanings">{meanings}</div>\n'
                f'        <div class="kanji-badges">'
                f'<span class="badge">✍️ {strokes} strokes</span>'
                f'<span class="index-badge">#{idx}</span></div>\n'
                f'      </div>\n'
                f'    </div>\n'
                f'    <div class="kanji-toggle">▼</div>\n'
                f'  </div>\n'
                f'  <div class="kanji-details">\n'
                f'    <div class="readings">\n'
                f'      <span class="reading-on">📖 On: {on_r}</span>\n'
                f'      <span class="reading-kun">🌿 Kun: {kun_r}</span>\n'
                f'    </div>\n'
            )

            # JLPT vocab groups — INSIDE the per-kanji loop
            for level in ['N5', 'N4', 'N3', 'N2', 'N1']:
                vlist = vocab_by_level.get(level)
                if not vlist:
                    continue
                html += (
                    f'    <div class="jlpt-group collapsed">\n'
                    f'      <div class="jlpt-header" onclick="toggleJlptGroup(this.parentElement)">\n'
                    f'        <span class="jlpt-badge">{level}</span>\n'
                    f'        <span class="jlpt-toggle">▼</span>\n'
                    f'      </div>\n'
                    f'      <div class="jlpt-content">\n'
                )
                for v in vlist:
                    k_chars = re.findall(r'[\u4e00-\u9faf]', v['expression'])
                    m_html = ''.join(
                        f'<div class="kanji-in-word"><span class="small-kanji">{k}</span> '
                        f'{kanji_meanings.get(k, "?")}</div>'
                        for k in k_chars
                    ) or '<div>No kanji</div>'
                    html += (
                        f'        <div class="vocab-item collapsed">\n'
                        f'          <div class="vocab-header" onclick="toggleVocab(this.parentElement)">\n'
                        f'            <div>\n'
                        f'              <div class="vocab-expression">{v["expression"]}</div>\n'
                        f'              <div class="vocab-reading">{v["reading"]}</div>\n'
                        f'              <div class="vocab-meaning">{v["meaning"]}</div>\n'
                        f'            </div>\n'
                        f'            <span class="vocab-toggle">▼</span>\n'
                        f'          </div>\n'
                        f'          <div class="vocab-kanji-meanings">{m_html}</div>\n'
                        f'        </div>\n'
                    )
                html += '      </div>\n    </div>\n'

            if not vocab_by_level:
                html += '    <div class="no-vocab">No vocabulary found</div>\n'

            # Close kanji-details + kanji-card
            html += '  </div>\n</div>\n'
            idx += 1

        # Close kanji-group-content + kanji-group-section
        html += '  </div>\n</div>\n'

    return html, idx


def create_kanji_fragments():
    """Generate per-grade HTML fragment files for the kanji study guide."""
    kanji_meanings = load_kanji_meanings()
    print(f"Loaded meanings for {len(kanji_meanings)} kanji")

    vocab_files = {'N5': 'n5.csv', 'N4': 'n4.csv', 'N3': 'n3.csv', 'N2': 'n2.csv', 'N1': 'n1.csv'}
    all_vocab = []
    for level, filename in vocab_files.items():
        if not Path(filename).exists():
            print(f"Warning: {filename} not found")
            continue
        df = pd.read_csv(filename)
        df.columns = df.columns.str.lower()
        df['jlpt_level'] = level
        all_vocab.append(df)

    if not all_vocab:
        print("Error: No vocabulary files found!")
        return

    vocab_df = pd.concat(all_vocab, ignore_index=True)
    vocab_df['extracted_jlpt'] = vocab_df['tags'].apply(extract_jlpt_level)
    vocab_df['final_jlpt'] = vocab_df['extracted_jlpt'].fillna(vocab_df['jlpt_level'])
    print(f"Loaded {len(vocab_df)} vocabulary entries")

    joyo_df = pd.read_csv('joyo.csv')
    joyo_df['grade'] = joyo_df['grade'].astype(str)
    print(f"Loaded {len(joyo_df)} kanji")

    # Build kanji -> vocab mapping grouped by JLPT level
    kanji_to_vocab = {}
    for _, row in vocab_df.iterrows():
        expression = str(row['expression'])
        for k in set(re.findall(r'[\u4e00-\u9faf]', expression)):
            kanji_to_vocab.setdefault(k, []).append({
                'expression': expression,
                'reading': row.get('reading', ''),
                'meaning': row.get('meaning', ''),
                'jlpt': row['final_jlpt'],
            })
    for k in kanji_to_vocab:
        grouped = {}
        for v in kanji_to_vocab[k]:
            grouped.setdefault(v['jlpt'], []).append(v)
        kanji_to_vocab[k] = grouped

    idx = 1
    created = []

    for grade in ['1', '2', '3', '4', '5', '6']:
        rows = list(joyo_df[joyo_df['grade'] == grade].iterrows())
        if not rows:
            continue
        html, idx = build_kanji_fragment(rows, kanji_to_vocab, kanji_meanings, idx)
        fname = f'kanji_grade_{grade}.html'
        Path(fname).write_text(html, encoding='utf-8')
        created.append(fname)
        print(f"✅ {fname} – {len(rows)} kanji")

    s_df = joyo_df[joyo_df['grade'] == 'S']
    if len(s_df) > 0:
        for part, fname in [
            (s_df.iloc[:370], 'kanji_grade_s1.html'),
            (s_df.iloc[370:740], 'kanji_grade_s2.html'),
            (s_df.iloc[740:], 'kanji_grade_s3.html'),
        ]:
            if len(part) == 0:
                continue
            rows = list(part.iterrows())
            html, idx = build_kanji_fragment(rows, kanji_to_vocab, kanji_meanings, idx)
            Path(fname).write_text(html, encoding='utf-8')
            created.append(fname)
            print(f"✅ {fname} – {len(rows)} kanji")

    print(f"\n✅ Created {len(created)} kanji fragment files")


if __name__ == "__main__":
    create_kanji_fragments()
