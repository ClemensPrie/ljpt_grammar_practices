import pandas as pd
import re
from pathlib import Path
from math import ceil


def load_kanji_meanings(joyo_file='joyo.csv'):
    """Load kanji meanings from joyo.csv into a dict."""
    if not Path(joyo_file).exists():
        return {}
    df = pd.read_csv(joyo_file)
    meanings = {}
    for _, row in df.iterrows():
        kanji = row['kanji']
        meaning = row.get('meanings', '')
        if pd.notna(meaning):
            meanings[kanji] = str(meaning).split('|')[0]
        else:
            meanings[kanji] = ''
    return meanings


def extract_jlpt_level(tags):
    if pd.isna(tags) or not isinstance(tags, str):
        return None
    match = re.search(r'JLPT_([Nn][1-5])', tags)
    if match:
        return match.group(1).upper()
    return None


def build_vocab_fragment(vocab_list, kanji_meanings, group_size=30):
    """Build an HTML fragment for a list of vocab rows, grouped into batches."""
    total = len(vocab_list)
    num_groups = ceil(total / group_size)
    html = f'<div class="stats">📖 {total} vocabulary words (groups of {group_size})</div>\n'

    for g in range(num_groups):
        lo = g * group_size
        hi = min(lo + group_size, total)
        group = vocab_list[lo:hi]

        html += (
            f'<div class="group-section collapsed">\n'
            f'  <div class="group-header" onclick="toggleGroup(this.parentElement)">\n'
            f'    <span>📚 Words {lo+1}–{hi} ({len(group)} items)</span>\n'
            f'    <span class="group-toggle-icon">▼</span>\n'
            f'  </div>\n'
            f'  <div class="group-content">\n'
        )

        for pos, row in enumerate(group):
            word_idx = lo + pos + 1
            expression = row['expression']
            reading = row.get('reading', '')
            meaning = row.get('meaning', '')

            k_chars = re.findall(r'[\u4e00-\u9faf]', str(expression))
            has_detail = len(k_chars) >= 2

            k_html = ''
            if has_detail:
                for k in k_chars:
                    km = kanji_meanings.get(k, 'Meaning not found')
                    k_html += (
                        f'<div class="kanji-in-word">'
                        f'<span class="small-kanji">{k}</span>'
                        f'<span class="kanji-meaning">{km}</span></div>'
                    )
            else:
                k_html = '<div class="kanji-in-word">(Fewer than 2 kanji – no breakdown)</div>'

            click_cls = ' clickable' if has_detail else ''
            onclick = ' onclick="toggleVocab(this.parentElement)"' if has_detail else ''
            toggle = '<span class="vocab-toggle">▼</span>' if has_detail else ''

            html += (
                f'    <div class="vocab-card collapsed">\n'
                f'      <div class="vocab-header{click_cls}"{onclick}>\n'
                f'        <div class="vocab-header-left">\n'
                f'          <div><span class="word-index">#{word_idx}</span>'
                f'<span class="vocab-expression">{expression}</span></div>\n'
                f'          <div class="vocab-reading">{reading}</div>\n'
                f'          <div class="vocab-meaning">{meaning}</div>\n'
                f'        </div>\n'
                f'        {toggle}\n'
                f'      </div>\n'
                f'      <div class="vocab-details">{k_html}</div>\n'
                f'    </div>\n'
            )

        html += '  </div>\n</div>\n'

    return html


def create_vocab_fragments():
    """Generate per-JLPT-level HTML fragment files."""
    kanji_meanings = load_kanji_meanings()
    print(f"Loaded meanings for {len(kanji_meanings)} kanji")

    vocab_files = {'N5': 'n5.csv', 'N4': 'n4.csv', 'N3': 'n3.csv', 'N2': 'n2.csv', 'N1': 'n1.csv'}
    all_vocab = []
    for level, filename in vocab_files.items():
        if not Path(filename).exists():
            print(f"Warning: {filename} not found")
            continue
        df = pd.read_csv(filename)
        df.columns = df.columns.str.lower()
        df['source_level'] = level
        df['extracted_jlpt'] = df['tags'].apply(extract_jlpt_level)
        df['final_jlpt'] = df['extracted_jlpt'].fillna(level)
        all_vocab.append(df)

    if not all_vocab:
        print("Error: No vocabulary files found!")
        return

    vocab_df = pd.concat(all_vocab, ignore_index=True)
    vocab_df = vocab_df.drop_duplicates(subset=['expression'])
    print(f"Total unique vocabulary entries: {len(vocab_df)}")

    level_order = ['N5', 'N4', 'N3', 'N2', 'N1']
    grouped = {lv: [] for lv in level_order}
    for _, row in vocab_df.iterrows():
        lv = row['final_jlpt']
        if lv in grouped:
            grouped[lv].append(row)

    created = []
    for lv in level_order:
        if not grouped[lv]:
            continue
        html = build_vocab_fragment(grouped[lv], kanji_meanings)
        fname = f'vocab_{lv.lower()}.html'
        Path(fname).write_text(html, encoding='utf-8')
        created.append(fname)
        print(f"✅ {fname} – {len(grouped[lv])} words")

    print(f"\n✅ Created {len(created)} vocab fragment files")


if __name__ == "__main__":
    create_vocab_fragments()
